package ua.pamyatnye.daty;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** После перезагрузки телефона или смены времени заново ставит напоминания. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Scheduler.ensureChannels(context);
        Scheduler.schedule(context);
    }
}
