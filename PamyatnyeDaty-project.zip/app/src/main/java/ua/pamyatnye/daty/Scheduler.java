package ua.pamyatnye.daty;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

/** Хранит список ближайших напоминаний и ставит системный будильник на ближайшее. */
public final class Scheduler {
    private static final String PREFS = "md_native";
    private static final String KEY = "items";
    private static final long GRACE_MS = 36L * 3600 * 1000;

    static final String[] SOUNDS = {"bell", "soft", "harp", "drops", "chime", "alarm", "none"};
    static final String[] NAMES = {"Колокольчик", "Мягкий аккорд", "Арфа", "Капли", "Маримба", "Будильник", "Без звука"};
    static final int[] RAW = {R.raw.snd_bell, R.raw.snd_soft, R.raw.snd_harp, R.raw.snd_drops, R.raw.snd_chime, R.raw.snd_alarm, 0};

    private Scheduler() {}

    static void ensureChannels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        for (int i = 0; i < SOUNDS.length; i++) {
            for (int v = 0; v < 2; v++) {
                boolean vib = v == 0;
                String id = "rem_" + SOUNDS[i] + (vib ? "_v" : "_n");
                if (nm.getNotificationChannel(id) != null) continue;
                NotificationChannel ch = new NotificationChannel(id,
                        "Напоминания · " + NAMES[i] + (vib ? " · с вибрацией" : ""),
                        NotificationManager.IMPORTANCE_HIGH);
                if (RAW[i] == 0) {
                    ch.setSound(null, null);
                } else {
                    Uri u = Uri.parse("android.resource://" + c.getPackageName() + "/" + RAW[i]);
                    AudioAttributes aa = new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build();
                    ch.setSound(u, aa);
                }
                ch.enableVibration(vib);
                if (vib) ch.setVibrationPattern(new long[]{0, 180, 90, 180});
                else ch.setVibrationPattern(new long[]{0});
                nm.createNotificationChannel(ch);
            }
        }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static JSONArray load(Context c) {
        try {
            return new JSONArray(prefs(c).getString(KEY, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    /** Вызывается из веб-части при каждом изменении событий или настроек. */
    static void save(Context c, String json) {
        prefs(c).edit().putString(KEY, json == null ? "[]" : json).apply();
        schedule(c);
    }

    static void schedule(Context c) {
        JSONArray a = load(c);
        long now = System.currentTimeMillis();
        long next = Long.MAX_VALUE;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            long at = o.optLong("at", 0);
            if (at > now - GRACE_MS && at < next) next = at;
        }
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (am == null) return;
        PendingIntent pi = PendingIntent.getBroadcast(c, 1,
                new Intent(c, ReminderReceiver.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
        if (next == Long.MAX_VALUE) return;
        long when = Math.max(next, now + 1500);
        boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    /** Срабатывание будильника: показать всё, что наступило, и завести следующий. */
    static void fire(Context c) {
        JSONArray a = load(c);
        long now = System.currentTimeMillis();
        JSONArray rest = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            long at = o.optLong("at", 0);
            if (at <= now + 60000) {
                if (now - at < GRACE_MS) {
                    post(c, o.optString("id").hashCode(), o.optString("title"),
                            o.optString("body"), o.optString("ch", "rem_bell_v"));
                }
            } else {
                rest.put(o);
            }
        }
        prefs(c).edit().putString(KEY, rest.toString()).apply();
        schedule(c);
    }

    static void post(Context c, int id, String title, String body, String channel) {
        ensureChannels(c);
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        if (channel == null || nm.getNotificationChannel(channel) == null) channel = "rem_bell_v";
        Intent open = new Intent(c, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, channel)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setCategory(Notification.CATEGORY_REMINDER)
                .setColor(0xFF7C6CF0)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        try {
            nm.notify(id, n);
        } catch (SecurityException ignored) {
            // нет разрешения на уведомления
        }
    }
}
